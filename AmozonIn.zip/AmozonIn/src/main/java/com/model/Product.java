package com.model;

public class Product {
	
	private int productid;
	private String ProductName;
	private String productDescription;
	private double price;

	public Product() {
		super();
	}

	public Product(int productid, String productName, String productDescription, double price) {
		super();
		this.productid = productid;
		ProductName = productName;
		this.productDescription = productDescription;
		this.price = price;
	}

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getProductName() {
		return ProductName;
	}

	public void setProductName(String productName) {
		ProductName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [productid=" + productid + ", ProductName=" + ProductName + ", productDescription="
				+ productDescription + ", price=" + price + "]";
	}

}
