package com.loginCustomer;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Login")
public class Login extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String name = request.getParameter("uname");
		String pass = request.getParameter("pass");
		out.print("<hr>");
		out.print("<h1 style='color:red;'>");
		out.print("<a href='http://localhost:8081/AmozonIn/Login?uname=farooque&pass=1234'>Login</a> &nbsp &nbsp");
		out.print("<a href=''>Card</a>&nbsp &nbsp");
		out.print("<a href='LogOut'>LogOut</a>");
		out.print("</h1>");

		out.print("<hr>");
		if (name.equals("farooque") && pass.equals("1234")) {
			// out.print("login sucessfully"+name);
			request.getRequestDispatcher("/Admin.html").forward(request, response);
			Cookie ck = new Cookie("ckid", name);
			response.addCookie(ck);
		} else {
			out.print("LOGIN FAILED");
			request.getRequestDispatcher("/customerLogin.html").include(request, response);

		}
	}

}
